'''
Created on Oct 5, 2018

@author: root
'''
from DST import DST_
from Sanitize import Sanitize_


class Flow_():
    def __init__(self, obj):
        self.DST=DST_(obj)  
        self.Sanitize=Sanitize_(obj)  












